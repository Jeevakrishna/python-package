from setuptools import setup, find_packages

setup(
    name="lexer-tools",  # Replace with your package name
    version="1.1.1",
    description="A Python package to save and manage files.",
    author="SeventyThree",
    author_email="73@gmail.com",
    packages=find_packages(),
    include_package_data=True,  # Include non-Python files
    package_data={
        "lexer": ["data/*.txt"],  # Include all .txt files in the data folder
    },
    install_requires=[],  # Add dependencies if needed
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)